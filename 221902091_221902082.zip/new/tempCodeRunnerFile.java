            "Select an Option", "Bit Stuffing", "Bit De-stuffing", "Character Stuffing",
            "Character De-Stuffing", "Dotted Decimal to Binary",
            "Binary to Dotted Decimal","IP Information", "IPv4 to IPv6", "Parity Check","Hamming Encode", 
            "Hamming Decode","Error Detection"